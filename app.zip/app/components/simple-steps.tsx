"use client"


export const SimpleSteps = () => {



    return (


    <div className="flex flex-col -mt-[20vh] lg:-mt-[40vh]">
            <div className="flex flex-col z-0  bg-secondary relative justify-end items-center p-10 gap-4 w-full h-[20vh] lg:h-[40vh]">


            </div>

            <div className="flex flex-col z-0 w-full bg-secondary relative pb-10 justify-end items-center gap-4  h-[20vh] lg:h-[40vh]">

                <small className=" p-2 px-4 border border-black rounded-[60px] font-bold uppercase text-[12px]">Brands we have worked with</small>

            </div>

        </div>

    )
};