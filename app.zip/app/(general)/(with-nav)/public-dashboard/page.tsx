"use client";

import { useState } from "react";
import { OrderStatusTrigger } from "./components/order-status-trigger";
import { OrderStatusModal } from "./components/order-status-modal";

export default function HomePage() {
  const [isModalOpen, setIsModalOpen] = useState(true);

  return (
    <div className="min-h-screen bg-primary">
      {/* Demo page content */}

      {/* Fixed order status trigger button */}
      <OrderStatusTrigger onClick={() => setIsModalOpen(true)} />

      {/* Order status modal */}
      <OrderStatusModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
      />
    </div>
  );
}
