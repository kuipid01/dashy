// import { Product } from "@/constants/types";

// export const products: Product[] = [
//   {
   
//     name: 'Premium Wireless Headphones',
//     price: 249.99,
//     rating: 4.8,
//     image: ['https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'],
   
//   },

// ];