import React from "react";
import Lightbox from "../components/light-box";

const page = () => {
  return (
    <div className=" bg-primary">
      <Lightbox />
    </div>
  );
};

export default page;
