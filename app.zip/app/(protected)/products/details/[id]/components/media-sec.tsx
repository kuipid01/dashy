"use client";
import React from "react";
// import TweetGenerator from "../tweet-generator";
// import { Product } from "@/app/(handlers)/types/product";

const MediaSec = () => {
  // const product: Product = {
  //   name: "Sample Product",
  //   description: "This is a great product that does amazing things.",
  //   price: 99,
  //   category: "NA",
  //   image: ["/assets/login.jpg", "/assets/login.jpg", "/assets/login.jpg"],
  //   videos: [],
  //   stock: 1,
  //   discountedPrice: 0,
  //   rating: 3
  // };

  return (
    <div className="grid grid-cols-1 gap-10">
      {/* <TweetGenerator product={product} /> */}
    </div>
  );
};

export default MediaSec;
