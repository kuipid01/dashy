"use client"
import React from 'react'

const Modifications = () => {
  return (
    <div>Modifications</div>
  )
}

export default Modifications